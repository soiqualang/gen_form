WebSql-Import-Export
====================

Retrieve WebSQL (sqlite) database as CSV, JSON or SQL
