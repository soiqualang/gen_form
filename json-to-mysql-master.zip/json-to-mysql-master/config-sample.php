<?php
/**
 * Licensed under Creative Commons 3.0 Attribution
 * Copyright Adam Wulf 2013
 */

define("ROOT", dirname(__FILE__) . "/");
define("DATABASE_HOST", "your.database.host");
define("DATABASE_NAME", "your_database_name");
define("DATABASE_USER", "your_database_user_name");
define("DATABASE_PASS", "your_database_password");

?>