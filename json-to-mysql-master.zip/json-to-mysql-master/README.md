json-to-mysql
=============

Easily take any JSON object and create+insert it into a mysql table built from its structure. Also search, update, index, and validate tables with JSON.
